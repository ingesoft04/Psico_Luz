// controllers/citasController.js
const { validationResult } = require('express-validator');
const db       = require('../config/database');
const redis    = require('../config/redis');
const AppError = require('../utils/AppError');
const { citaQueue } = require('../jobs/queues');

// ─── Helpers ──────────────────────────────────────────────

const CACHE_KEY = {
  lista:    (uid, rol) => `citas:lista:${rol}:${uid}`,
  detalle:  (id) => `citas:det:${id}`,
  hoy:      () => `citas:hoy:${new Date().toISOString().split('T')[0]}`,
};

// ─── LISTAR ───────────────────────────────────────────────

exports.listar = async (req, res) => {
  const { page = 1, limit = 20, estado, desde, hasta } = req.query;
  const offset = (page - 1) * limit;
  const user   = req.user;

  const cacheKey = CACHE_KEY.lista(user.id, user.rol) + `:${page}:${estado||''}`;
  const cached   = await redis.get(cacheKey);
  if (cached) return res.json({ ok: true, cached: true, ...JSON.parse(cached) });

  // Pacientes solo ven sus propias citas
  const esAdmin = ['admin','psicologa','recepcionista'].includes(user.rol);
  const params  = esAdmin ? [] : [user.id];
  let where     = esAdmin ? 'WHERE 1=1' : 'WHERE c.paciente_id=$1';
  if (estado) { params.push(estado); where += ` AND c.estado=$${params.length}`; }
  if (desde)  { params.push(desde);  where += ` AND c.fecha>=$${params.length}`; }
  if (hasta)  { params.push(hasta);  where += ` AND c.fecha<=$${params.length}`; }

  params.push(limit, offset);
  const { rows } = await db.query(`
    SELECT c.id, c.fecha, c.hora_inicio, c.hora_fin, c.modalidad,
           c.tipo_sesion, c.estado, c.motivo, c.link_videollamada,
           u.nombre || ' ' || u.apellido AS paciente,
           u.telefono, u.whatsapp
    FROM app.citas c
    JOIN app.usuarios u ON u.id = c.paciente_id
    ${where}
    ORDER BY c.fecha DESC, c.hora_inicio DESC
    LIMIT $${params.length - 1} OFFSET $${params.length}
  `, params);

  const payload = { data: rows, page: +page, limit: +limit };
  await redis.setex(cacheKey, 300, JSON.stringify(payload));
  res.json({ ok: true, ...payload });
};

// ─── HOY ──────────────────────────────────────────────────

exports.hoy = async (req, res) => {
  const cacheKey = CACHE_KEY.hoy();
  const data = await redis.cacheOr(cacheKey, async () => {
    const { rows } = await db.query('SELECT * FROM app.v_citas_hoy');
    return rows;
  }, 120); // cache 2 min
  res.json({ ok: true, data });
};

// ─── OBTENER UNA ──────────────────────────────────────────

exports.obtener = async (req, res) => {
  const { id } = req.params;
  const data = await redis.cacheOr(CACHE_KEY.detalle(id), async () => {
    const { rows } = await db.query(`
      SELECT c.*, u.nombre, u.apellido, u.email, u.telefono, u.whatsapp
      FROM app.citas c
      JOIN app.usuarios u ON u.id = c.paciente_id
      WHERE c.id = $1
    `, [id]);
    return rows[0] || null;
  });
  if (!data) throw new AppError('Cita no encontrada', 404);

  // Paciente solo puede ver su propia cita
  if (req.user.rol === 'paciente' && data.paciente_id !== req.user.id)
    throw new AppError('Sin permiso', 403);

  res.json({ ok: true, data });
};

// ─── CREAR ────────────────────────────────────────────────

exports.crear = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ ok: false, errors: errors.array() });

  const { fecha, hora_inicio, hora_fin, modalidad, tipo_sesion, motivo, notas_previas, link_videollamada } = req.body;
  const paciente_id = req.user.rol === 'paciente' ? req.user.id : req.body.paciente_id;
  if (!paciente_id) throw new AppError('paciente_id requerido', 400);

  // Verificar disponibilidad
  const { rows: conflict } = await db.query(
    'SELECT id FROM app.citas WHERE fecha=$1 AND hora_inicio=$2 AND modalidad=$3 AND estado NOT IN ($4,$5)',
    [fecha, hora_inicio, modalidad, 'cancelada', 'no_asistio']
  );
  if (conflict.length) throw new AppError('Ese horario ya no está disponible', 409);

  const { rows } = await db.query(`
    INSERT INTO app.citas
      (paciente_id, fecha, hora_inicio, hora_fin, modalidad, tipo_sesion, motivo, notas_previas, link_videollamada, created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
    RETURNING *
  `, [
    paciente_id, fecha, hora_inicio,
    hora_fin || hora_inicio, // si no especifica hora_fin
    modalidad, tipo_sesion || 'individual',
    motivo, notas_previas, link_videollamada, req.user.id
  ]);

  const cita = rows[0];

  // Invalidar caches
  await redis.invalidate(`citas:lista:*`);
  await redis.del(CACHE_KEY.hoy());

  // Encolar recordatorio automático (24h antes)
  await citaQueue.add('recordatorio-cita', { citaId: cita.id }, {
    delay: Math.max(0, new Date(`${fecha}T${hora_inicio}:00`).getTime() - Date.now() - 24 * 3600 * 1000),
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 }
  });

  res.status(201).json({ ok: true, message: '¡Cita agendada exitosamente!', data: cita });
};

// ─── ACTUALIZAR ───────────────────────────────────────────

exports.actualizar = async (req, res) => {
  const { id } = req.params;
  const { fecha, hora_inicio, hora_fin, modalidad, motivo, notas_previas, link_videollamada } = req.body;

  const { rows } = await db.query(`
    UPDATE app.citas SET
      fecha=$1, hora_inicio=$2, hora_fin=$3, modalidad=$4,
      motivo=$5, notas_previas=$6, link_videollamada=$7, updated_at=NOW()
    WHERE id=$8 AND estado NOT IN ('cancelada','completada')
    RETURNING *
  `, [fecha, hora_inicio, hora_fin, modalidad, motivo, notas_previas, link_videollamada, id]);

  if (!rows.length) throw new AppError('Cita no encontrada o no modificable', 404);

  await redis.del(CACHE_KEY.detalle(id));
  await redis.invalidate('citas:lista:*');

  res.json({ ok: true, message: 'Cita actualizada', data: rows[0] });
};

// ─── CAMBIAR ESTADO ───────────────────────────────────────

exports.cambiarEstado = async (req, res) => {
  const { id } = req.params;
  const { estado } = req.body;
  const validos = ['pendiente','confirmada','en_curso','completada','cancelada','no_asistio'];
  if (!validos.includes(estado)) throw new AppError('Estado inválido', 400);

  const { rows } = await db.query(
    'UPDATE app.citas SET estado=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
    [estado, id]
  );
  if (!rows.length) throw new AppError('Cita no encontrada', 404);

  await redis.del(CACHE_KEY.detalle(id));
  await redis.invalidate('citas:lista:*');
  await redis.del(CACHE_KEY.hoy());

  // Si completada, encolar resumen automático con IA
  if (estado === 'completada') {
    const { aiQueue } = require('../jobs/queues');
    await aiQueue.add('resumen-sesion', { citaId: id });
  }

  res.json({ ok: true, data: rows[0] });
};

// ─── CANCELAR ─────────────────────────────────────────────

exports.cancelar = async (req, res) => {
  const { id } = req.params;
  const { motivo_cancelacion } = req.body;

  const { rows } = await db.query(`
    UPDATE app.citas SET
      estado='cancelada', cancelada_por=$1,
      motivo_cancelacion=$2, updated_at=NOW()
    WHERE id=$3 AND estado NOT IN ('cancelada','completada')
    RETURNING *
  `, [req.user.id, motivo_cancelacion, id]);

  if (!rows.length) throw new AppError('Cita no encontrada o no cancelable', 404);

  await redis.del(CACHE_KEY.detalle(id));
  await redis.invalidate('citas:lista:*');

  res.json({ ok: true, message: 'Cita cancelada', data: rows[0] });
};
