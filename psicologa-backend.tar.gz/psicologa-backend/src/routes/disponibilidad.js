// Re-exportado desde src/routes/usuarios.js (archivo consolidado)
// Este archivo existe para que app.js pueda importarlo individualmente

const allRoutes  = require('./usuarios');
module.exports   = allRoutes; // stub — cada ruta se registra en app.js con su path
