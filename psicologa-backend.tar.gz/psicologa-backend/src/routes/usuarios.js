// ════════════════════════════════════════════════════════════
//  routes/usuarios.js
// ════════════════════════════════════════════════════════════
const router = require('express').Router();
const db     = require('../config/database');
const redis  = require('../config/redis');
const { auth, rol } = require('../middleware/auth');
const AppError = require('../utils/AppError');

router.use(auth);

// Perfil propio
router.get('/me', async (req, res) => {
  const { rows } = await db.query(
    'SELECT id,nombre,apellido,email,telefono,whatsapp,ciudad,departamento,fecha_nacimiento,genero,foto_url,created_at FROM app.usuarios WHERE id=$1',
    [req.user.id]
  );
  res.json({ ok: true, data: rows[0] });
});

// Actualizar perfil
router.put('/me', async (req, res) => {
  const { nombre, apellido, telefono, whatsapp, ciudad, departamento, fecha_nacimiento, genero } = req.body;
  const { rows } = await db.query(`
    UPDATE app.usuarios SET
      nombre=$1, apellido=$2, telefono=$3, whatsapp=$4,
      ciudad=$5, departamento=$6, fecha_nacimiento=$7, genero=$8, updated_at=NOW()
    WHERE id=$9 RETURNING id,nombre,apellido,email,telefono,whatsapp,ciudad
  `, [nombre, apellido, telefono, whatsapp, ciudad, departamento, fecha_nacimiento, genero, req.user.id]);
  await redis.del(`user:${req.user.id}`);
  res.json({ ok: true, data: rows[0] });
});

// Listar pacientes (admin/psicóloga)
router.get('/', rol('admin','psicologa','recepcionista'), async (req, res) => {
  const { page=1, limit=30, q, rol: rolFiltro='paciente' } = req.query;
  const offset = (page-1)*limit;
  const params = [rolFiltro, limit, offset];
  let where = 'WHERE rol=$1';
  if (q) { params.unshift(`%${q}%`); where = `WHERE (nombre ILIKE $1 OR apellido ILIKE $1 OR email ILIKE $1) AND rol=$2`; params.splice(2,0,rolFiltro); }

  const { rows } = await db.query(`
    SELECT id,nombre,apellido,email,telefono,ciudad,activo,ultimo_login,created_at
    FROM app.usuarios ${where}
    ORDER BY created_at DESC LIMIT $${params.length-1} OFFSET $${params.length}
  `, params);
  res.json({ ok: true, data: rows, page: +page });
});

// Obtener un paciente específico
router.get('/:id', rol('admin','psicologa','recepcionista'), async (req, res) => {
  const { rows } = await db.query(
    'SELECT * FROM app.usuarios WHERE id=$1',
    [req.params.id]
  );
  if (!rows.length) throw new AppError('Usuario no encontrado', 404);
  const { password_hash, token_reset, token_verificacion, ...safe } = rows[0];
  res.json({ ok: true, data: safe });
});

// Activar/desactivar usuario
router.patch('/:id/activo', rol('admin'), async (req, res) => {
  const { activo } = req.body;
  await db.query('UPDATE app.usuarios SET activo=$1 WHERE id=$2', [activo, req.params.id]);
  await redis.del(`user:${req.params.id}`);
  res.json({ ok: true });
});

module.exports = router;


// ════════════════════════════════════════════════════════════
//  routes/disponibilidad.js
// ════════════════════════════════════════════════════════════
const routerDisp = require('express').Router();

routerDisp.get('/', async (req, res) => {
  const { rows } = await db.query(
    'SELECT * FROM app.disponibilidad WHERE activo=true ORDER BY dia_semana, hora_inicio'
  );
  res.json({ ok: true, data: rows });
});

// Slots disponibles para una fecha específica
routerDisp.get('/slots', async (req, res) => {
  const { fecha, modalidad = 'presencial' } = req.query;
  if (!fecha) throw new AppError('fecha requerida', 400);

  const cacheKey = `slots:${fecha}:${modalidad}`;
  const cached   = await redis.get(cacheKey);
  if (cached) return res.json({ ok: true, cached: true, data: JSON.parse(cached) });

  const dia = new Date(fecha).getDay();
  const { rows: disponibles } = await db.query(
    'SELECT hora_inicio, hora_fin FROM app.disponibilidad WHERE dia_semana=$1 AND modalidad=$2 AND activo=true',
    [dia, modalidad]
  );

  const { rows: ocupadas } = await db.query(
    "SELECT hora_inicio FROM app.citas WHERE fecha=$1 AND modalidad=$2 AND estado NOT IN ('cancelada','no_asistio')",
    [fecha, modalidad]
  );

  const ocupadasSet = new Set(ocupadas.map(r => r.hora_inicio));

  // Generar slots de 1 hora
  const slots = [];
  for (const { hora_inicio, hora_fin } of disponibles) {
    let [h, m] = hora_inicio.split(':').map(Number);
    const [hf] = hora_fin.split(':').map(Number);
    while (h < hf) {
      const slot = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
      slots.push({ hora: slot, disponible: !ocupadasSet.has(slot) });
      h++;
    }
  }

  await redis.setex(cacheKey, 300, JSON.stringify(slots));
  res.json({ ok: true, data: slots });
});

module.exports = routerDisp;


// ════════════════════════════════════════════════════════════
//  routes/pagos.js
// ════════════════════════════════════════════════════════════
const routerPagos = require('express').Router();

routerPagos.use(auth);

routerPagos.get('/', async (req, res) => {
  const esAdmin = ['admin','psicologa','recepcionista'].includes(req.user.rol);
  const params  = esAdmin ? [] : [req.user.id];
  const where   = esAdmin ? '' : 'WHERE p.paciente_id=$1';
  const { rows } = await db.query(`
    SELECT p.*, c.fecha, c.hora_inicio, u.nombre || ' ' || u.apellido AS paciente
    FROM app.pagos p
    JOIN app.citas c ON c.id = p.cita_id
    JOIN app.usuarios u ON u.id = p.paciente_id
    ${where} ORDER BY p.created_at DESC LIMIT 50
  `, params);
  res.json({ ok: true, data: rows });
});

routerPagos.post('/', async (req, res) => {
  const { cita_id, monto, metodo, notas } = req.body;
  const { rows } = await db.query(
    'SELECT paciente_id FROM app.citas WHERE id=$1', [cita_id]
  );
  if (!rows.length) throw new AppError('Cita no encontrada', 404);
  const { rows: p } = await db.query(`
    INSERT INTO app.pagos (cita_id, paciente_id, monto, metodo, notas)
    VALUES ($1,$2,$3,$4,$5) RETURNING *
  `, [cita_id, rows[0].paciente_id, monto, metodo || 'efectivo', notas]);
  res.status(201).json({ ok: true, data: p[0] });
});

routerPagos.patch('/:id/estado', rol('admin','recepcionista'), async (req, res) => {
  const { estado } = req.body;
  const { rows } = await db.query(
    'UPDATE app.pagos SET estado=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
    [estado, req.params.id]
  );
  if (!rows.length) throw new AppError('Pago no encontrado', 404);
  res.json({ ok: true, data: rows[0] });
});

module.exports = routerPagos;


// ════════════════════════════════════════════════════════════
//  routes/notas.js
// ════════════════════════════════════════════════════════════
const routerNotas = require('express').Router();

routerNotas.use(auth, rol('admin','psicologa'));

routerNotas.get('/:citaId', async (req, res) => {
  const { rows } = await db.query(
    'SELECT * FROM app.notas_sesion WHERE cita_id=$1 ORDER BY created_at DESC',
    [req.params.citaId]
  );
  res.json({ ok: true, data: rows });
});

routerNotas.post('/:citaId', async (req, res) => {
  const { contenido, etiquetas, estado_animo, progreso, tareas_asignadas, next_steps, es_privada } = req.body;
  const { rows: cita } = await db.query('SELECT paciente_id FROM app.citas WHERE id=$1', [req.params.citaId]);
  if (!cita.length) throw new AppError('Cita no encontrada', 404);

  const { rows } = await db.query(`
    INSERT INTO app.notas_sesion
      (cita_id, paciente_id, contenido, etiquetas, estado_animo, progreso, tareas_asignadas, next_steps, es_privada)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *
  `, [req.params.citaId, cita[0].paciente_id, contenido, etiquetas, estado_animo, progreso, tareas_asignadas, next_steps, es_privada !== false]);

  // Encolar resumen automático con IA
  const { aiQueue } = require('../jobs/queues');
  await aiQueue.add('resumen-sesion', { citaId: req.params.citaId });

  res.status(201).json({ ok: true, data: rows[0] });
});

module.exports = routerNotas;


// ════════════════════════════════════════════════════════════
//  routes/notificaciones.js
// ════════════════════════════════════════════════════════════
const routerNotif = require('express').Router();

routerNotif.use(auth);

routerNotif.get('/', async (req, res) => {
  const { rows } = await db.query(
    'SELECT * FROM app.notificaciones WHERE usuario_id=$1 ORDER BY created_at DESC LIMIT 30',
    [req.user.id]
  );
  const noLeidas = rows.filter(n => !n.leida).length;
  res.json({ ok: true, data: rows, noLeidas });
});

routerNotif.put('/:id/leer', async (req, res) => {
  await db.query(
    'UPDATE app.notificaciones SET leida=true WHERE id=$1 AND usuario_id=$2',
    [req.params.id, req.user.id]
  );
  res.json({ ok: true });
});

routerNotif.put('/leer-todas', async (req, res) => {
  await db.query(
    'UPDATE app.notificaciones SET leida=true WHERE usuario_id=$1',
    [req.user.id]
  );
  res.json({ ok: true });
});

module.exports = routerNotif;


// ════════════════════════════════════════════════════════════
//  routes/admin.js
// ════════════════════════════════════════════════════════════
const routerAdmin = require('express').Router();

routerAdmin.use(auth, rol('admin','psicologa'));

// Dashboard principal
routerAdmin.get('/dashboard', async (req, res) => {
  const cacheKey = 'admin:dashboard';
  const data = await redis.cacheOr(cacheKey, async () => {
    const { rows } = await db.query('SELECT * FROM app.v_dashboard');
    return rows[0];
  }, 60); // cache 1 minuto
  res.json({ ok: true, data });
});

// Reporte de citas por mes
routerAdmin.get('/reportes/citas', async (req, res) => {
  const { rows } = await db.query(`
    SELECT
      DATE_TRUNC('month', fecha) AS mes,
      COUNT(*) AS total,
      COUNT(*) FILTER (WHERE estado='completada') AS completadas,
      COUNT(*) FILTER (WHERE estado='cancelada')  AS canceladas,
      COUNT(*) FILTER (WHERE modalidad='virtual')  AS virtuales,
      COUNT(*) FILTER (WHERE modalidad='presencial') AS presenciales
    FROM app.citas
    WHERE fecha >= NOW() - INTERVAL '12 months'
    GROUP BY DATE_TRUNC('month', fecha)
    ORDER BY mes DESC
  `);
  res.json({ ok: true, data: rows });
});

// Reporte de ingresos por mes
routerAdmin.get('/reportes/ingresos', async (req, res) => {
  const { rows } = await db.query(`
    SELECT
      DATE_TRUNC('month', created_at) AS mes,
      SUM(monto) FILTER (WHERE estado='pagado') AS ingresos,
      COUNT(*) FILTER (WHERE estado='pagado')   AS pagos_exitosos,
      COUNT(*) FILTER (WHERE estado='fallido')  AS pagos_fallidos
    FROM app.pagos
    WHERE created_at >= NOW() - INTERVAL '12 months'
    GROUP BY DATE_TRUNC('month', created_at)
    ORDER BY mes DESC
  `);
  res.json({ ok: true, data: rows });
});

// Ficha clínica de un paciente
routerAdmin.get('/fichas/:pacienteId', async (req, res) => {
  const { rows } = await db.query(
    'SELECT * FROM app.fichas_clinicas WHERE paciente_id=$1',
    [req.params.pacienteId]
  );
  res.json({ ok: true, data: rows[0] || null });
});

routerAdmin.post('/fichas/:pacienteId', async (req, res) => {
  const cols = ['motivo_consulta','antecedentes','diagnostico','observaciones','objetivos','medicamentos','alergias','contacto_emergencia_nombre','contacto_emergencia_tel','datos_extra'];
  const vals = cols.map(c => req.body[c]);
  const { rows } = await db.query(`
    INSERT INTO app.fichas_clinicas (paciente_id, ${cols.join(',')}, creado_por)
    VALUES ($1, ${cols.map((_,i) => `$${i+2}`).join(',')}, $${cols.length+2})
    ON CONFLICT (paciente_id) DO UPDATE SET
      ${cols.map((c,i) => `${c}=EXCLUDED.${c}`).join(',')}
    RETURNING *
  `, [req.params.pacienteId, ...vals, req.user.id]);
  res.status(201).json({ ok: true, data: rows[0] });
});

module.exports = routerAdmin;
