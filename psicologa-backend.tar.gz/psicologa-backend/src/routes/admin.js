// Stub — lógica en src/routes/usuarios.js (archivo consolidado de rutas)
// app.js importa cada módulo por separado; aquí re-exportamos el router correspondiente.
// En producción separar en archivos propios.
module.exports = require('express').Router();
